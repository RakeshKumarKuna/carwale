//package com.trisun.entity;
//
//import jakarta.persistence.Entity;
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//
//@AllArgsConstructor
//@NoArgsConstructor
//@Data
//@Entity
//public class Review {
//
//	
//	private Integer rating;
//	private String review;
//	private String performance;
//	
//}
