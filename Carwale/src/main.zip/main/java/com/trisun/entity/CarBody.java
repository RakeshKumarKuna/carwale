//package com.trisun.entity;
//
//import jakarta.persistence.Entity;
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//
//@AllArgsConstructor
//@NoArgsConstructor
//@Data
//@Entity
//public class CarBody {
//
//
//	private Integer seatingCapacity;
//	private Integer noOfDoors;
//	private String length;
//	private String width;
//	private String height;
//	
//	
//}
