package com.trisun.core;

public enum FuelType {

	PETROL,DIESEL,ELECTRIC,GAS,HYBRID
}
